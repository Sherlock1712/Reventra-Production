Reventra v2.5 - Full project. Edit apps/web/.env.example locally to create .env with real secrets before deploying.
